# from functools import reduce
import shutil
import os

filename = "student_scores.txt"


def file_operations():
    if os.path.exists(filename):
        print("file exists")
        file_copied = shutil.copyfile(filename, "copy_file.txt")
        file_calculation(file_copied)
        os.remove(file_copied)
    else:
        print("File don't exists")


def file_calculation(file_path):
    with open(file_path, 'r') as file:
         # Skip the header line
        header = file.readline() 
        for line in file:
            print(line)
            # Split by whitespace 
            parts = line.split()  # Split by whitespace (can be space or tab)
            
            # Get the first element of the array (the name)
            name = parts[0]
            # convert object to array and cast each element to int
            scores = list(map(int, parts[1:]))

            # total_score = reduce(lambda x, y: x + y, scores)
            # print(sum(scores))

            # Calculate the average of the scores
            average_score = sum(scores) / len(scores)
            
            # Print the name and average score
            print(f'{name}: {average_score:.2f}')

file_operations()